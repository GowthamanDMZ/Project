package com.ust.integration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

import com.ust.integration.ibenrollment.report.processor.CsvProcessor;

public class ClassToInvoke {

	
	public static void main(String[] args) throws Exception {
		
		Properties prop = getProperties();
		String localPath = prop.getProperty("localPath");
		
		String csvfilename="C:\\Users\\bkajjam\\Desktop\\Karthik\\CSV\\PHP_SHOVDIPFile_20190228_las.b104309.dat.xml.csv";
		
		String csvFolder=prop.getProperty("IB_CLAIMS_IB_INPUT_FILE");
		
		CamelContext context = new DefaultCamelContext();
		try {
			
			List<File> csvFileList = new ArrayList<File>();
			File file = new File(csvFolder);
	        File[] files = file.listFiles();
	        try {
		        for(File f: files){
		            System.out.println(f.getName());
		            csvFileList.add(f);
		        }
	        }catch(Exception e) {
	        	System.out.println("no files");
	        }
			
			
			for(int i=0;i<3;i++) {
				context.addRoutes(new RouteBuilder() {
					@Override
					public void configure() throws Exception {
								from("direct:testCsv").to("file:"+localPath).process(new CsvProcessor(csvfilename,csvFileList));
					}
	
				});
	
				context.start();
				ProducerTemplate template = context.createProducerTemplate();
				InputStream orderxml = new FileInputStream(csvfilename);
				template.setDefaultEndpointUri("direct:testCsv");
				template.sendBody("direct:testCsv",orderxml);
			}
		} finally {
			context.stop();
		}
	}
	
	public static Properties getProperties() {
		
		Properties prop = new Properties();
		InputStream input = null;
		try {
			String filename = "application.properties";
			input = ClassToInvoke.class.getClassLoader().getResourceAsStream(filename);
			if(input==null){
		            System.out.println("Sorry, unable to find " + filename);
			    return prop;
			}
			prop.load(input);
			
		}catch (IOException e) {
			System.out.println("Sorry, unable to find property file");
		}
		return prop;
	}
	
}
