package com.ust.integration.ibenrollment.report.processor;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.imageio.ImageIO;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;

import com.sun.media.jai.codec.FileSeekableStream;
import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageEncoder;
import com.sun.media.jai.codec.SeekableStream;
import com.sun.media.jai.codec.TIFFDecodeParam;
import com.ust.integration.ClassToInvoke;

@Component
public class CsvProcessor implements Processor {
	
	
	private String fileName;
	private List<File> csvFileList = new ArrayList<File>();
	
	public CsvProcessor(String fileName, List<File> csvFileList) {
		// TODO Auto-generated constructor stub
		this.fileName=fileName;
		this.csvFileList=csvFileList;
	}
	
	String networkPath = "";

	public void process(Exchange exchange) throws Exception {

		FileInputStream fis = (FileInputStream) exchange.getIn().getBody();
		
		for(File f :csvFileList) {
			
			BufferedReader brMainCsv = new BufferedReader(new FileReader(f));
			
			String fileNametoRead[] = f.getName().split("\\.");
			String localPath = "";
			
			Properties prop = getProperties();
			networkPath = prop.getProperty("networkPath");
			localPath = prop.getProperty("localPath");
			/*System.out.println(prop.getProperty("IB_CLAIMS_IB_INPUT_FILE"));
			System.out.println(prop.getProperty("IB_CLAIMS_IB_LIST_FILE"));
			System.out.println(prop.getProperty("IB_CLAIMS_IB_FOLDER"));
			System.out.println(prop.getProperty("IB_CLAIMS_IB_OUTPUT_FILE"));*/
			
			
			try {
				File netFile=new File(networkPath);
				for(File file:netFile.listFiles()) {
					File newFilePath=new File(localPath+file.getName());
					if(!newFilePath.exists()) {
					FileCopyUtils.copy(file,newFilePath);
					}
				}
			}catch(Exception e) {
				
			}
			

			System.out.println(fileNametoRead[1]);
			BufferedReader br = null;
			BufferedWriter bw=null;

			try {
				brMainCsv = new BufferedReader(new InputStreamReader(new FileInputStream(new File(fileName))));
			
				bw=new BufferedWriter(new FileWriter(new File(localPath+"output"+".csv")));
				
				String mainline = brMainCsv.readLine();
				String line = null;
				while ((mainline=brMainCsv.readLine()) != null) {
					List<BufferedImage> bufferedImages = new ArrayList<BufferedImage>();
					br = new BufferedReader(
							new InputStreamReader(new FileInputStream(localPath
									+ fileNametoRead[1] + ".lst")));
					String[] mainmetadata = mainline.split("\\|");
					String mainaccNum = mainmetadata[0];

					mainaccNum = mainaccNum.substring(0, mainaccNum.length() - 2);

					BufferedImage img2 = null;
					while ((line = br.readLine()) != null) {
						String[] metadata = line.split("\\|");
						String accNum = metadata[1];
						accNum = accNum.substring(0, accNum.length() - 2);
						if (mainaccNum.equalsIgnoreCase(accNum)) {
							File newFile = new File(localPath + metadata[0]);
							System.out.println("is file existis " + newFile.exists());

							File tempFile = new File(localPath + metadata[0] + ".png");

							SeekableStream s = new FileSeekableStream(newFile);
							TIFFDecodeParam param = null;
							com.sun.media.jai.codec.ImageDecoder dec = ImageCodec.createImageDecoder("tiff", s, param);
							RenderedImage op = dec.decodeAsRenderedImage(0);

							FileOutputStream fos = new FileOutputStream(tempFile);
							com.sun.media.jai.codec.JPEGEncodeParam jpgparam = new com.sun.media.jai.codec.JPEGEncodeParam();
							jpgparam.setQuality(100);
							ImageEncoder en = ImageCodec.createImageEncoder("jpeg", fos, jpgparam);
							en.encode(op);
							fos.flush();
							fos.close();

							img2 = ImageIO.read(tempFile);
							if (img2 != null) {
								bufferedImages.add(img2);
							}
						}
					}
					
					if(fileNametoRead!=null && fileNametoRead[1]!=null) {
						BufferedImage[] arr = new BufferedImage[bufferedImages.size()]; 
						arr = bufferedImages.toArray(arr); 

						BufferedImage joinedImg = joinBufferedImage(arr);
						File fileCombined=new File("C:\\combined2\\"+ mainaccNum +".png");
						ImageIO.write(joinedImg, "png",fileCombined );
						bw.append(mainline+fileCombined.getAbsolutePath()+"\n");
						
					}
				}

			} catch (IOException ioe) {
				ioe.printStackTrace();
			} finally {
				br.close();
				fis.close();
				brMainCsv.close();
				bw.close();
			}
		}
		

	}
	
	public BufferedImage joinBufferedImage(BufferedImage[] a) {

		int offset = 2;
		int minwidth = 0;
		int minheight = 0;

		int maxwidth = 0;
		int maxheight = 0;
		
		for (BufferedImage i : a){
			if(maxwidth< i.getWidth()) {
			maxwidth =  i.getWidth();
			}
			maxheight = maxheight + i.getHeight();
		}
		
		maxwidth = maxwidth + offset;
		maxheight = maxheight + offset;
		BufferedImage newImage = new BufferedImage(maxwidth, maxheight, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = newImage.createGraphics();
		Color oldColor = g2.getColor();
		g2.setPaint(Color.BLACK);
		g2.fillRect(0, 0, maxwidth, maxheight);
		g2.setColor(oldColor);

		for (BufferedImage i : a) {
			g2.drawImage(i, null, 0, minheight );
			minwidth = i.getWidth();
			minheight = minheight+ i.getHeight();
		}
		
		g2.dispose();
		return newImage;
	}
	
	
	public Properties getProperties() {
		
		Properties prop = new Properties();
		InputStream input = null;
		
		try {
			String filename = "application.properties";
			input = ClassToInvoke.class.getClassLoader().getResourceAsStream(filename);
			if(input==null){
		            System.out.println("Sorry, unable to find " + filename);
			    return prop;
			}
			prop.load(input);
			
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		return prop;
	}
}


