package com.javapointers.model;

public class UserProfile {

	private String firstName;
	private String age;
	private String ciy;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getCiy() {
		return ciy;
	}
	public void setCiy(String ciy) {
		this.ciy = ciy;
	}
	
	
}
