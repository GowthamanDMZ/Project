package com.javapointers.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.javapointers.model.User;

/**
 * @author Jerry Conde, webmaster@javapointers.com
 * @since 8/9/2016
 */
@Controller
public class HomeController {

    @RequestMapping("/")
    public String viewHome() {
        return "index";
    }
    
    
    @RequestMapping("/loginform")
    public String formPost(User user, Model model) {
        model.addAttribute("user", user);
        return "aboutUs";
    }
    
    @RequestMapping(value = "/aboutUs")
    public String aboutUsPage() {
    	//String url = "/aboutUs.html";
        return "aboutUs";
    }
    
    @RequestMapping(value = "/profilePage")
    public String method() {
    	//String url = "/profileSubmit.html";
    	return "profileSubmit";    
    }
    
    
    @RequestMapping("/submitProfile")
    public String submitProfile(User user, Model model) {
        model.addAttribute("user", user);
        return "home";
    }
}


