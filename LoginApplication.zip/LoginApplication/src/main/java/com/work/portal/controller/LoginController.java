
package com.work.portal.controller;

import java.io.IOException;
import java.io.InputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.work.portal.model.User;
import com.work.portal.model.UserProfile;
import com.work.portal.repository.UserProfileRepository;

@RestController
public class LoginController {
 
 @RequestMapping("/helloworld")
 public ModelAndView hello() {
 
  String helloWorldMessage = "Hello world from java2blog!";
  return new ModelAndView("hello", "message", helloWorldMessage);
 }
 
 
 @Autowired
 private UserProfileRepository userRepo;
	
 @RequestMapping("/")
 public ModelAndView viewHome() {
	 return new ModelAndView("index");
 }
 
 
 @RequestMapping("/loginform")
 public ModelAndView formPost(User user, Model model) {
     model.addAttribute("user", user);
     return new ModelAndView("aboutUs");
 }
 
 @RequestMapping(value = "/aboutUs")
 public ModelAndView aboutUsPage() {
	 return new ModelAndView("aboutUs");
 }
 
 @RequestMapping(value = "/profilePage")
 public ModelAndView method() {
	 return new ModelAndView("profileSubmit");
 }
 
 
 @RequestMapping(value = "/submitProfile", method = RequestMethod.POST)
 public String submitProfile(UserProfile userProf, Model model) {
     model.addAttribute("user", userProf);
    
     try {
         String fileName = userProf.getFile().getOriginalFilename();
         InputStream is = userProf.getFile().getInputStream();
         System.out.println(fileName.length());
     } catch (IOException e) {

    	 String msg = String.format("Failed to store file", userProf.getFile().getName());
    	 e.printStackTrace();
     }
     //userRepo.save(userProf);
     return "user saved";
 }
 
 
}
