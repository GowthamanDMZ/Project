package io.cryptocontrol.cryptonewsapi.models;

/**
 * @author enamakel@cryptocontrol.io
 */
public enum Language {
    ENGLISH,
    RUSSIAN,
    GERMAN,
    SPANISH,
    ITALIAN,
    PORTUGUESE,
    CHINESE,
    JAPANESE,
    KOREAN
}
