package io.cryptocontrol.cryptonewsapi;

import io.cryptocontrol.cryptonewsapi.models.CoinDetail;

public class CryptoControlController {

	public static void main(String[] args) {
		System.out.println("im in");

		CryptoControlApi api = new CryptoControlApi("456ad613eec2c5371e0d6eda9ee7d4d9");
		api.enableSentiment();

		// Get rich metadata (wallets, blockexplorers, twitter handles etc..) for
		// ethereum
		api.getCoinDetails("ethereum", new CryptoControlApi.OnResponseHandler<CoinDetail>() {
			@Override
			public void onSuccess(CoinDetail body) {
				System.out.println(body.getDescription());
			}

			@Override
			public void onFailure(Exception e) {
				e.printStackTrace();
			}
		});
	}
}
