package com.javainuse;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;


@SpringBootApplication
public class SpringBootHelloWorldApplication {

	public static void main(String[] args) {

		SpringApplication.run(
				new Object[] { SpringBootHelloWorldApplication.class }, args);
	}
	
	/*private final MessageProducer messageProducer; 
	
	 public SpringBootHelloWorldApplication(MessageProducer messageProducer){      
		 this.messageProducer = messageProducer;   
	 }*/
	
	@Autowired
	private AmqpTemplate amqpTemplate;
	
	@Value("${javainuse.rabbitmq.exchange}")
	private String exchange;
	
	@Value("${javainuse.rabbitmq.routingkey}")
	private String routingkey;	
	
	@EventListener(ApplicationReadyEvent.class)
	public void doOnStart() {
		System.out.println("Event listener");
		amqpTemplate.convertAndSend(exchange, routingkey, "hi from here");
		//messageProducer.sendMessage("hi from here");
	}
}